package com.youngmoney2.api;

import org.json.JSONObject;

/**
 * Classe para encapsular respostas da API
 */
public class ApiResponse {
    private boolean success;
    private String message;
    private JSONObject data;
    private String error;
    
    public ApiResponse(JSONObject json) {
        try {
            this.success = json.optBoolean("success", false);
            this.message = json.optString("message", "");
            this.data = json.optJSONObject("data");
            this.error = json.optString("error", null);
        } catch (Exception e) {
            this.success = false;
            this.error = e.getMessage();
        }
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public JSONObject getData() {
        return data;
    }
    
    public String getError() {
        return error != null ? error : message;
    }
    
    public boolean hasData() {
        return data != null;
    }
}
