package com.youngmoney2.api;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Gerenciador de tokens XReq
 * Responsável por gerar e gerenciar tokens únicos para cada requisição
 */
public class XReqManager {
    private static final String TAG = "XReqManager";
    private static final String BASE_URL = "https://youngmoney-api-production.up.railway.app/";
    
    private static XReqManager instance;
    private OkHttpClient client;
    private Context context;
    
    /**
     * Callback para obtenção de XReq token
     */
    public interface XReqCallback {
        void onSuccess(String xreqToken);
        void onError(String error);
    }
    
    /**
     * Construtor privado (Singleton)
     */
    private XReqManager(Context context) {
        this.context = context.getApplicationContext();
        
        // Cliente HTTP dedicado para XReq
        this.client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .build();
    }
    
    /**
     * Obtém instância única do XReqManager
     */
    public static synchronized XReqManager getInstance(Context context) {
        if (instance == null) {
            instance = new XReqManager(context);
        }
        return instance;
    }
    
    /**
     * Gera um novo token XReq
     * Deve ser chamado antes de cada requisição à API
     */
    public void generateXReq(final XReqCallback callback) {
        generateXReq(null, callback);
    }
    
    /**
     * Gera um novo token XReq com Bearer token (para usuários autenticados)
     */
    public void generateXReq(String bearerToken, final XReqCallback callback) {
        try {
            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "xreq/generate.php")
                    .post(RequestBody.create("", MediaType.parse("application/json")));
            
            // Adicionar Bearer token se fornecido
            if (bearerToken != null && !bearerToken.isEmpty()) {
                requestBuilder.addHeader("Authorization", "Bearer " + bearerToken);
            }
            
            Request request = requestBuilder.build();
            
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    Log.e(TAG, "Failed to generate XReq token", e);
                    callback.onError("Erro ao gerar XReq: " + e.getMessage());
                }
                
                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    try {
                        String responseBody = response.body().string();
                        
                        if (!response.isSuccessful()) {
                            Log.e(TAG, "XReq generation failed: " + responseBody);
                            callback.onError("Erro HTTP " + response.code());
                            return;
                        }
                        
                        JSONObject json = new JSONObject(responseBody);
                        
                        if (json.getBoolean("success")) {
                            JSONObject data = json.getJSONObject("data");
                            String xreqToken = data.getString("xreq");
                            
                            Log.d(TAG, "XReq token generated successfully");
                            callback.onSuccess(xreqToken);
                        } else {
                            String error = json.optString("error", "Erro desconhecido");
                            Log.e(TAG, "XReq generation error: " + error);
                            callback.onError(error);
                        }
                        
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to parse XReq response", e);
                        callback.onError("Erro ao processar resposta: " + e.getMessage());
                    }
                }
            });
            
        } catch (Exception e) {
            Log.e(TAG, "Exception generating XReq", e);
            callback.onError("Erro ao gerar XReq: " + e.getMessage());
        }
    }
    
    /**
     * Gera XReq de forma síncrona (para uso em threads de background)
     * NÃO USAR NA THREAD PRINCIPAL!
     */
    public String generateXReqSync(String bearerToken) throws Exception {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "xreq/generate.php")
                .post(RequestBody.create("", MediaType.parse("application/json")));
        
        if (bearerToken != null && !bearerToken.isEmpty()) {
            requestBuilder.addHeader("Authorization", "Bearer " + bearerToken);
        }
        
        Request request = requestBuilder.build();
        
        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body().string();
            
            if (!response.isSuccessful()) {
                throw new Exception("HTTP " + response.code() + ": " + responseBody);
            }
            
            JSONObject json = new JSONObject(responseBody);
            
            if (json.getBoolean("success")) {
                JSONObject data = json.getJSONObject("data");
                return data.getString("xreq");
            } else {
                throw new Exception(json.optString("error", "Erro desconhecido"));
            }
        }
    }
}
