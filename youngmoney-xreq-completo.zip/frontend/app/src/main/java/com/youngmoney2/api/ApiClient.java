package com.youngmoney2.api;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Cliente para comunicação com API REST
 * Substitui o Firebase Realtime Database e Authentication
 */
public class ApiClient {
    private static final String TAG = "ApiClient";

    // URL da API no Railway.app
    private static final String BASE_URL = "https://youngmoney-api-production.up.railway.app/";

    private static ApiClient instance;
    private OkHttpClient client;
    private Context context;
    private String authToken;
    private XReqManager xreqManager;

    // SharedPreferences para armazenar token
    private static final String PREFS_NAME = "YoungMoneyPrefs";
    private static final String KEY_AUTH_TOKEN = "auth_token";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_NAME = "user_name";

    /**
     * Construtor privado (Singleton)
     */
    private ApiClient(Context context) {
        this.context = context.getApplicationContext();

        // Configurar OkHttpClient com timeouts
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        // Carregar token salvo
        loadAuthToken();

        // Inicializar XReqManager
        this.xreqManager = XReqManager.getInstance(context);
    }

    /**
     * Obtém instância única do ApiClient
     */
    public static synchronized ApiClient getInstance(Context context) {
        if (instance == null) {
            instance = new ApiClient(context);
        }
        return instance;
    }

    /**
     * Define o token de autenticação
     */
    public void setAuthToken(String token) {
        this.authToken = token;
        saveAuthToken(token);
    }

    /**
     * Obtém o token de autenticação
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     * Verifica se usuário está autenticado
     */
    public boolean isAuthenticated() {
        return authToken != null && !authToken.isEmpty();
    }

    /**
     * Salva token no SharedPreferences
     */
    private void saveAuthToken(String token) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_AUTH_TOKEN, token).apply();
    }

    /**
     * Carrega token do SharedPreferences
     */
    private void loadAuthToken() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.authToken = prefs.getString(KEY_AUTH_TOKEN, null);
    }

    /**
     * Salva dados do usuário
     */
    public void saveUserData(String userId, String email, String name) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(KEY_USER_ID, userId)
                .putString(KEY_USER_EMAIL, email)
                .putString(KEY_USER_NAME, name)
                .apply();
    }

    /**
     * Obtém ID do usuário salvo
     */
    public String getUserId() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_USER_ID, null);
    }

    /**
     * Limpa dados de autenticação (logout)
     */
    public void clearAuth() {
        this.authToken = null;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
    }

    // ========================================
    // INTERFACES DE CALLBACK
    // ========================================

    public interface ApiCallback {
        void onSuccess(JSONObject response);
        void onError(String error);
    }

    public interface ApiArrayCallback {
        void onSuccess(org.json.JSONArray response);
        void onError(String error);
    }

    // ========================================
    // MÉTODOS DE AUTENTICAÇÃO
    // ========================================

    /**
     * Login com Google Token + Device ID
     */
    public void login(String googleToken, String deviceId, ApiCallback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("google_token", googleToken);
            json.put("device_id", deviceId);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "api/v1/auth/google-login.php")
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Login error", e);
            callback.onError("Erro ao fazer login: " + e.getMessage());
        }
    }

    /**
     * Login com Device ID (automático)
     */
    public void login(String deviceId, ApiCallback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("device_id", deviceId);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "api/v1/auth/device-login.php")
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Login error", e);
            callback.onError("Erro ao fazer login: " + e.getMessage());
        }
    }

    /**
     * Logout
     */
    public void logout(ApiCallback callback) {
        Request request = new Request.Builder()
                .url(BASE_URL + "auth/logout.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .post(RequestBody.create("", MediaType.parse("application/json")))
                .build();

        executeRequest(request, new ApiCallback() {
            @Override
            public void onSuccess(JSONObject response) {
                clearAuth();
                callback.onSuccess(response);
            }

            @Override
            public void onError(String error) {
                clearAuth();
                callback.onError(error);
            }
        });
    }

    // ========================================
    // MÉTODOS DE USUÁRIO
    // ========================================

    /**
     * Obtém perfil do usuário
     */
    public void getUserProfile(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "user/profile.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    /**
     * Atualiza perfil do usuário
     */
    public void updateUserProfile(JSONObject userData, ApiCallback callback) {
        try {
            RequestBody body = RequestBody.create(
                    userData.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "user/profile.php")
                    .addHeader("Authorization", "Bearer " + authToken)
                    .put(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Update profile error", e);
            callback.onError("Erro ao atualizar perfil: " + e.getMessage());
        }
    }

    /**
     * Obtém saldo do usuário
     */
    public void getUserBalance(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "user/balance.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    // ========================================
    // MÉTODOS DE RANKING
    // ========================================

    /**
     * Obtém lista de ranking
     */
    public void getRanking(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "ranking/list.php")
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    /**
     * Adiciona pontos ao usuário
     */
    public void addPoints(int points, String activity, ApiCallback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("points", points);
            json.put("activity", activity);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "ranking/add_points.php")
                    .addHeader("Authorization", "Bearer " + authToken)
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Add points error", e);
            callback.onError("Erro ao adicionar pontos: " + e.getMessage());
        }
    }

    /**
     * Obtém posição do usuário no ranking
     */
    public void getUserPosition(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "ranking/user_position.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    // ========================================
    // MÉTODOS DE SAQUE
    // ========================================

    /**
     * Solicita saque
     */
    public void requestWithdrawal(double amount, String pixKeyType, String pixKey, ApiCallback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("amount", amount);
            json.put("pix_key_type", pixKeyType);
            json.put("pix_key", pixKey);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "withdraw/request.php")
                    .addHeader("Authorization", "Bearer " + authToken)
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Request withdrawal error", e);
            callback.onError("Erro ao solicitar saque: " + e.getMessage());
        }
    }

    /**
     * Obtém histórico de saques
     */
    public void getWithdrawalHistory(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "withdraw/history.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    /**
     * Obtém histórico de pontos
     */
    public void getPointsHistory(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "history/points.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    // ========================================
    // MÉTODOS DE CONVITE
    // ========================================

    /**
     * Valida código de convite
     */
    public void validateInviteCode(String inviteCode, ApiCallback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("invite_code", inviteCode);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "invite/validate.php")
                    .addHeader("Authorization", "Bearer " + authToken)
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Validate invite error", e);
            callback.onError("Erro ao validar convite: " + e.getMessage());
        }
    }

    /**
     * Obtém código de convite do usuário
     */
    public void getMyInviteCode(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "invite/my_code.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    // ========================================
    // MÉTODOS DE NOTIFICAÇÕES
    // ========================================

    /**
     * Obtém lista de notificações
     */
    public void getNotifications(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "notifications/list.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    /**
     * Marca notificação como lida
     */
    public void markNotificationAsRead(int notificationId, ApiCallback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("notification_id", notificationId);

            RequestBody body = RequestBody.create(
                    json.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "notifications/mark_read.php")
                    .addHeader("Authorization", "Bearer " + authToken)
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Mark notification error", e);
            callback.onError("Erro ao marcar notificação: " + e.getMessage());
        }
    }

    // ========================================
    // MÉTODOS DE CONFIGURAÇÕES
    // ========================================

    /**
     * Obtém configurações do usuário
     */
    public void getSettings(ApiCallback callback) {
        Request.Builder requestBuilder = new Request.Builder()
                .url(BASE_URL + "settings/get.php")
                .addHeader("Authorization", "Bearer " + authToken)
                .get()
                ;
            executeRequestWithXReq(requestBuilder, callback);
    }

    /**
     * Atualiza configurações do usuário
     */
    public void updateSettings(JSONObject settings, ApiCallback callback) {
        try {
            RequestBody body = RequestBody.create(
                    settings.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request.Builder requestBuilder = new Request.Builder()
                    .url(BASE_URL + "settings/update.php")
                    .addHeader("Authorization", "Bearer " + authToken)
                    .post(body)
                    ;
            executeRequestWithXReq(requestBuilder, callback);

        } catch (Exception e) {
            Log.e(TAG, "Update settings error", e);
            callback.onError("Erro ao atualizar configurações: " + e.getMessage());
        }
    }

    // ========================================
    // MÉTODO GENÉRICO DE EXECUÇÃO
    // ========================================

    /**
     * Executa requisição HTTP de forma assíncrona
     */
    private void executeRequest(Request request, ApiCallback callback) {
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e(TAG, "Request failed", e);
                callback.onError("Erro de conexão: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try {
                    String responseBody = response.body().string();
                    Log.d(TAG, "Response: " + responseBody);

                    if (!response.isSuccessful()) {
                        callback.onError("Erro HTTP " + response.code() + ": " + responseBody);
                        return;
                    }

                    JSONObject json = new JSONObject(responseBody);
                    callback.onSuccess(json);

                } catch (Exception e) {
                    Log.e(TAG, "Parse response error", e);
                    callback.onError("Erro ao processar resposta: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Executa requisição HTTP com XReq token
     */
    private void executeRequestWithXReq(final Request.Builder requestBuilder, final ApiCallback callback) {
        // Gerar XReq token
        xreqManager.generateXReq(authToken, new XReqManager.XReqCallback() {
            @Override
            public void onSuccess(String xreqToken) {
                // Adicionar XReq ao header
                Request request = requestBuilder
                        .addHeader("X-Req", xreqToken)
                        .build();
                
                // Executar requisição
                executeRequest(request, callback);
            }
            
            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to generate XReq: " + error);
                callback.onError("Erro ao gerar token de segurança: " + error);
            }
        });
    }

    /**
     * Solicita saque
     */
    public void requestWithdraw(JSONObject withdrawData, ApiCallback callback) {
        String url = BASE_URL + "/withdraw/request.php";

        RequestBody body = RequestBody.create(
                withdrawData.toString(),
                MediaType.parse("application/json")
        );

        Request.Builder requestBuilder = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", "Bearer " + getAuthToken());

        executeRequestWithXReq(requestBuilder, callback);
    }

}
