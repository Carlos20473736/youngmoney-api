package com.youngmoney2.api;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Wrapper para ApiClient que adiciona XReq automaticamente
 */
public class ApiClientWithXReq {
    private static final String TAG = "ApiClientWithXReq";
    
    private ApiClient apiClient;
    private XReqManager xreqManager;
    private Context context;
    
    public ApiClientWithXReq(Context context) {
        this.context = context;
        this.apiClient = ApiClient.getInstance(context);
        this.xreqManager = XReqManager.getInstance(context);
    }
    
    /**
     * Executa requisição com XReq automático
     */
    private void executeWithXReq(final RequestExecutor executor, final ApiClient.ApiCallback callback) {
        // Gerar XReq token
        xreqManager.generateXReq(apiClient.getAuthToken(), new XReqManager.XReqCallback() {
            @Override
            public void onSuccess(String xreqToken) {
                // Executar requisição com XReq
                executor.execute(xreqToken, callback);
            }
            
            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to generate XReq: " + error);
                callback.onError("Erro ao gerar token de segurança: " + error);
            }
        });
    }
    
    /**
     * Interface para executar requisição com XReq
     */
    private interface RequestExecutor {
        void execute(String xreqToken, ApiClient.ApiCallback callback);
    }
    
    // ========================================
    // MÉTODOS PÚBLICOS COM XREQ
    // ========================================
    
    /**
     * Adiciona pontos ao usuário (com XReq)
     */
    public void addPoints(final int points, final String activity, final ApiClient.ApiCallback callback) {
        executeWithXReq(new RequestExecutor() {
            @Override
            public void execute(String xreqToken, ApiClient.ApiCallback callback) {
                try {
                    JSONObject json = new JSONObject();
                    json.put("points", points);
                    json.put("activity", activity);
                    
                    apiClient.addPointsWithXReq(json, xreqToken, callback);
                } catch (Exception e) {
                    callback.onError("Erro ao adicionar pontos: " + e.getMessage());
                }
            }
        }, callback);
    }
    
    /**
     * Obtém saldo do usuário (com XReq)
     */
    public void getUserBalance(final ApiClient.ApiCallback callback) {
        executeWithXReq(new RequestExecutor() {
            @Override
            public void execute(String xreqToken, ApiClient.ApiCallback callback) {
                apiClient.getUserBalanceWithXReq(xreqToken, callback);
            }
        }, callback);
    }
    
    /**
     * Obtém perfil do usuário (com XReq)
     */
    public void getUserProfile(final ApiClient.ApiCallback callback) {
        executeWithXReq(new RequestExecutor() {
            @Override
            public void execute(String xreqToken, ApiClient.ApiCallback callback) {
                apiClient.getUserProfileWithXReq(xreqToken, callback);
            }
        }, callback);
    }
    
    /**
     * Solicita saque (com XReq)
     */
    public void requestWithdraw(final JSONObject withdrawData, final ApiClient.ApiCallback callback) {
        executeWithXReq(new RequestExecutor() {
            @Override
            public void execute(String xreqToken, ApiClient.ApiCallback callback) {
                apiClient.requestWithdrawWithXReq(withdrawData, xreqToken, callback);
            }
        }, callback);
    }
    
    /**
     * Obtém histórico de saques (com XReq)
     */
    public void getWithdrawHistory(final ApiClient.ApiCallback callback) {
        executeWithXReq(new RequestExecutor() {
            @Override
            public void execute(String xreqToken, ApiClient.ApiCallback callback) {
                apiClient.getWithdrawHistoryWithXReq(xreqToken, callback);
            }
        }, callback);
    }
    
    /**
     * Obtém histórico de pontos (com XReq)
     */
    public void getPointsHistory(final ApiClient.ApiCallback callback) {
        executeWithXReq(new RequestExecutor() {
            @Override
            public void execute(String xreqToken, ApiClient.ApiCallback callback) {
                apiClient.getPointsHistoryWithXReq(xreqToken, callback);
            }
        }, callback);
    }
}
