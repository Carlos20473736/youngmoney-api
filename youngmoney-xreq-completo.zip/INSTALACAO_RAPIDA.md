# 🚀 Instalação Rápida - Sistema XReq

## ⚡ Resumo

Sistema de proteção anti-script que adiciona tokens únicos (uso único) em cada requisição.

## 📦 O que foi modificado

### Backend (PHP)
- ✅ 17 endpoints protegidos com validação XReq
- ✅ Novo endpoint `/xreq/generate.php`
- ✅ Nova tabela `xreq_tokens` no banco de dados

### Frontend (Android)
- ✅ Novo arquivo `XReqManager.java`
- ✅ `ApiClient.java` modificado (XReq automático)

## 🔧 Passo a Passo

### 1️⃣ Backend - Banco de Dados

Execute o SQL no seu banco de dados:

```bash
mysql -u seu_usuario -p seu_banco < backend/setup_xreq_table.sql
```

Ou execute manualmente no phpMyAdmin/Adminer.

### 2️⃣ Backend - Upload dos Arquivos

```bash
# Fazer upload da pasta backend/ para seu servidor
# Estrutura:
# /api/
#   /xreq/
#     - generate.php (NOVO)
#     - validate.php (NOVO)
#   /ranking/
#     - add_points.php (MODIFICADO)
#     - list.php (MODIFICADO)
#     - user_position.php (MODIFICADO)
#   /user/
#     - balance.php (MODIFICADO)
#     - profile.php (MODIFICADO)
#   ... (todos os outros endpoints modificados)
```

### 3️⃣ Frontend - Arquivos Android

**Opção A: Substituir tudo (recomendado)**

```bash
# Copiar XReqManager.java (NOVO)
cp frontend/app/src/main/java/com/youngmoney2/api/XReqManager.java \
   seu-projeto/app/src/main/java/com/youngmoney2/api/

# Substituir ApiClient.java (MODIFICADO)
cp frontend/app/src/main/java/com/youngmoney2/api/ApiClient.java \
   seu-projeto/app/src/main/java/com/youngmoney2/api/
```

**Opção B: Modificar manualmente**

Se você fez modificações personalizadas no `ApiClient.java`, siga o guia em `MODIFICACOES_APICLIENT.md`.

### 4️⃣ Rebuild do App

```bash
cd seu-projeto
./gradlew clean build
```

## ✅ Verificar Instalação

### Teste Backend

```bash
curl -X POST https://sua-api.com/xreq/generate.php
```

Deve retornar:
```json
{
  "success": true,
  "data": {
    "xreq": "a1b2c3d4...",
    "expires_in": 300
  }
}
```

### Teste App

1. Compile e instale o app
2. Faça login
3. Execute qualquer ação (adicionar pontos, ver perfil, etc)
4. Verifique logs do Android:

```
D/XReqManager: XReq token generated successfully
D/ApiClient: Response: {"success":true,...}
```

## ⚠️ Problemas Comuns

### Backend retorna erro 500

**Solução**: Verificar se tabela `xreq_tokens` foi criada

```sql
SHOW TABLES LIKE 'xreq_tokens';
```

### App não compila

**Solução**: Verificar se `XReqManager.java` está no lugar certo:

```
app/src/main/java/com/youngmoney2/api/XReqManager.java
```

### Erro "XReq token não fornecido"

**Solução**: Verificar se `ApiClient.java` foi substituído corretamente

### Endpoints retornam 403

**Solução**: Verificar se CORS está configurado com `X-Req`:

```php
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Req');
```

## 📊 Monitorar Funcionamento

```sql
-- Ver tokens gerados recentemente
SELECT * FROM xreq_tokens 
ORDER BY created_at DESC 
LIMIT 10;

-- Contar tokens usados vs não usados
SELECT is_used, COUNT(*) 
FROM xreq_tokens 
GROUP BY is_used;
```

## 🎯 Pronto!

Agora seu sistema está protegido contra scripts automatizados. Cada requisição precisa de um token único que só pode ser usado uma vez!

## 📚 Documentação Completa

Para mais detalhes, consulte `README_XREQ.md`.

---

**Tempo estimado de instalação**: 15-30 minutos
