#!/bin/bash

# Script para aplicar validação XReq em todos os endpoints protegidos

BACKEND_DIR="/home/ubuntu/youngmoney-xreq/backend"

# Lista de arquivos que precisam de XReq (exceto auth)
FILES=(
    "api/v1/points.php"
    "api/v1/users.php"
    "api/v1/withdrawals.php"
    "history/points.php"
    "history/withdrawals.php"
    "invite/my_code.php"
    "invite/validate.php"
    "notifications/list.php"
    "notifications/mark_read.php"
    "ranking/list.php"
    "ranking/user_position.php"
    "settings/get.php"
    "settings/update.php"
    "user/balance.php"
    "user/profile.php"
    "withdraw/history.php"
    "withdraw/request.php"
)

echo "Aplicando validação XReq em ${#FILES[@]} arquivos..."

for file in "${FILES[@]}"; do
    filepath="$BACKEND_DIR/$file"
    
    if [ -f "$filepath" ]; then
        echo "Processando: $file"
        
        # Backup
        cp "$filepath" "$filepath.bak"
        
        # 1. Adicionar X-Req no header CORS
        sed -i "s/Authorization'/Authorization, X-Req'/g" "$filepath"
        
        # 2. Adicionar require do validate.php após database.php
        sed -i "/require_once.*database\.php/a require_once __DIR__ . '/../xreq/validate.php';" "$filepath"
        
        # 3. Adicionar validação XReq no início do try
        sed -i "/^try {/a \    // Validar XReq token\n    validateXReq();\n" "$filepath"
        
        echo "  ✓ Aplicado"
    else
        echo "  ✗ Arquivo não encontrado: $file"
    fi
done

echo ""
echo "Concluído! ${#FILES[@]} arquivos processados."
echo "Backups salvos com extensão .bak"
