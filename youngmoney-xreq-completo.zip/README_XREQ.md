# Sistema XReq - Proteção Anti-Script

## 📋 Visão Geral

O sistema **XReq** (X-Request) é uma camada de segurança implementada no projeto Young Money para prevenir automação e uso de scripts maliciosos. Cada requisição à API requer um token único e temporário que só pode ser usado uma vez.

## 🔒 Como Funciona

### Fluxo de Segurança

1. **Cliente solicita XReq token**
   - Antes de cada requisição protegida, o app solicita um token XReq
   - Endpoint: `POST /xreq/generate.php`

2. **Servidor gera token único**
   - Token de 64 caracteres hexadecimais (256 bits)
   - Salvo no banco de dados com timestamp
   - Válido por 5 minutos

3. **Cliente envia requisição com XReq**
   - Token incluído no header `X-Req`
   - Junto com o Bearer token de autenticação

4. **Servidor valida XReq**
   - Verifica se token existe
   - Verifica se não foi usado
   - Verifica se não expirou
   - Marca como usado após validação

5. **Token invalidado**
   - Após uso, token não pode ser reutilizado
   - Tokens expirados são limpos automaticamente

## 🛠️ Implementação

### Backend (PHP)

#### Arquivos Criados

1. **`xreq/generate.php`** - Gera tokens XReq
2. **`xreq/validate.php`** - Valida tokens XReq
3. **`setup_xreq_table.sql`** - Cria tabela no banco de dados

#### Tabela do Banco de Dados

```sql
CREATE TABLE xreq_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(64) NOT NULL UNIQUE,
    user_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_at TIMESTAMP NULL,
    is_used BOOLEAN DEFAULT FALSE,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL
);
```

#### Endpoints Protegidos

Todos os endpoints abaixo agora requerem XReq:

- ✅ `/api/v1/points.php`
- ✅ `/api/v1/users.php`
- ✅ `/api/v1/withdrawals.php`
- ✅ `/history/points.php`
- ✅ `/history/withdrawals.php`
- ✅ `/invite/my_code.php`
- ✅ `/invite/validate.php`
- ✅ `/notifications/list.php`
- ✅ `/notifications/mark_read.php`
- ✅ `/ranking/add_points.php`
- ✅ `/ranking/list.php`
- ✅ `/ranking/user_position.php`
- ✅ `/settings/get.php`
- ✅ `/settings/update.php`
- ✅ `/user/balance.php`
- ✅ `/user/profile.php`
- ✅ `/withdraw/history.php`
- ✅ `/withdraw/request.php`

#### Endpoints Públicos (sem XReq)

- `/api/v1/auth/google-login.php` - Login com Google
- `/api/v1/auth/device-login.php` - Login com Device ID
- `/xreq/generate.php` - Geração de XReq

### Frontend (Android)

#### Arquivos Criados

1. **`XReqManager.java`** - Gerenciador de tokens XReq
2. **`ApiClientWithXReq.java`** - Wrapper opcional do ApiClient

#### Modificações no ApiClient.java

- Adicionado campo `XReqManager`
- Adicionado método `executeRequestWithXReq()`
- Todos os métodos protegidos agora usam XReq automaticamente

#### Uso Transparente

O sistema XReq é **completamente transparente** para o desenvolvedor:

```java
// Código permanece o mesmo
ApiClient apiClient = ApiClient.getInstance(context);
apiClient.addPoints(100, "Jogo completado", new ApiClient.ApiCallback() {
    @Override
    public void onSuccess(JSONObject response) {
        // XReq é gerado e validado automaticamente
    }
    
    @Override
    public void onError(String error) {
        // Erros de XReq são tratados automaticamente
    }
});
```

## 🚀 Instalação

### 1. Backend (PHP)

```bash
# 1. Copiar arquivos modificados para o servidor
cp -r backend/* /seu/servidor/api/

# 2. Executar script SQL
mysql -u usuario -p banco_de_dados < setup_xreq_table.sql

# 3. Verificar permissões
chmod 644 xreq/*.php
```

### 2. Frontend (Android)

```bash
# 1. Copiar arquivos novos
cp frontend/app/src/main/java/com/youngmoney2/api/XReqManager.java \
   seu-projeto/app/src/main/java/com/youngmoney2/api/

# 2. Substituir ApiClient.java modificado
cp frontend/app/src/main/java/com/youngmoney2/api/ApiClient.java \
   seu-projeto/app/src/main/java/com/youngmoney2/api/

# 3. Rebuild do projeto
./gradlew clean build
```

## 🔍 Testando

### Teste 1: Gerar XReq Token

```bash
curl -X POST https://sua-api.com/xreq/generate.php \
  -H "Content-Type: application/json"
```

Resposta esperada:
```json
{
  "success": true,
  "data": {
    "xreq": "a1b2c3d4e5f6...",
    "expires_in": 300
  }
}
```

### Teste 2: Usar XReq em Requisição

```bash
curl -X POST https://sua-api.com/ranking/add_points.php \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN" \
  -H "X-Req: a1b2c3d4e5f6..." \
  -d '{"points": 100, "description": "Teste"}'
```

### Teste 3: Tentar Reutilizar XReq (deve falhar)

```bash
# Usar o mesmo XReq token novamente
curl -X POST https://sua-api.com/ranking/add_points.php \
  -H "X-Req: a1b2c3d4e5f6..." \
  ...
```

Resposta esperada:
```json
{
  "success": false,
  "error": "XReq token já foi usado",
  "code": "XREQ_ALREADY_USED"
}
```

## 📊 Códigos de Erro XReq

| Código | Descrição |
|--------|-----------|
| `XREQ_MISSING` | Header X-Req não fornecido |
| `XREQ_INVALID_FORMAT` | Token não tem formato válido (64 hex) |
| `XREQ_NOT_FOUND` | Token não existe no banco de dados |
| `XREQ_ALREADY_USED` | Token já foi usado anteriormente |
| `XREQ_EXPIRED` | Token expirou (mais de 5 minutos) |
| `XREQ_VALIDATION_ERROR` | Erro interno ao validar token |

## ⚙️ Configurações

### Tempo de Expiração

Modificar em `xreq/validate.php`:

```php
$expirationTime = 5 * 60; // 5 minutos (padrão)
```

### Limpeza Automática

Eventos MySQL configurados:

- **Tokens não usados**: Limpos após 5 minutos
- **Tokens usados**: Limpos após 1 hora

Para modificar, editar `setup_xreq_table.sql`.

## 🔐 Segurança

### Proteções Implementadas

1. ✅ **Token único por requisição** - Previne replay attacks
2. ✅ **Expiração temporal** - Tokens válidos por apenas 5 minutos
3. ✅ **Uso único** - Token invalidado após primeiro uso
4. ✅ **Geração criptográfica** - 256 bits de entropia
5. ✅ **Validação de formato** - Apenas tokens válidos são aceitos
6. ✅ **Rastreamento** - IP e User-Agent registrados
7. ✅ **Limpeza automática** - Tokens antigos removidos

### Limitações

- **Não protege contra**: Ataques de força bruta no Bearer token
- **Não substitui**: HTTPS/TLS (sempre use conexão segura)
- **Não previne**: Ataques de usuários legítimos com tokens válidos

### Recomendações Adicionais

1. Implementar **rate limiting** por IP/usuário
2. Monitorar **padrões suspeitos** de uso
3. Adicionar **CAPTCHA** em operações sensíveis
4. Implementar **2FA** para saques
5. Usar **HTTPS** obrigatoriamente

## 📈 Monitoramento

### Queries Úteis

```sql
-- Tokens gerados nas últimas 24h
SELECT COUNT(*) FROM xreq_tokens 
WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR);

-- Tokens usados vs não usados
SELECT is_used, COUNT(*) 
FROM xreq_tokens 
GROUP BY is_used;

-- Usuários mais ativos
SELECT user_id, COUNT(*) as requests 
FROM xreq_tokens 
WHERE user_id IS NOT NULL 
GROUP BY user_id 
ORDER BY requests DESC 
LIMIT 10;

-- IPs suspeitos (muitas requisições)
SELECT ip_address, COUNT(*) as requests 
FROM xreq_tokens 
GROUP BY ip_address 
HAVING requests > 1000 
ORDER BY requests DESC;
```

## 🐛 Troubleshooting

### Erro: "XReq token não fornecido"

**Causa**: Header `X-Req` não está sendo enviado

**Solução**: Verificar se `ApiClient.java` foi atualizado corretamente

### Erro: "XReq token expirado"

**Causa**: Token gerado há mais de 5 minutos

**Solução**: Gerar novo token antes de cada requisição

### Erro: "XReq token já foi usado"

**Causa**: Tentativa de reutilizar token

**Solução**: Gerar novo token para cada requisição

### App não compila após modificações

**Causa**: Falta importar `XReqManager`

**Solução**: Adicionar arquivo `XReqManager.java` ao projeto

## 📝 Changelog

### v1.0.0 (2025-11-06)

- ✅ Implementação inicial do sistema XReq
- ✅ Integração com backend PHP
- ✅ Integração com frontend Android
- ✅ Proteção de 17 endpoints
- ✅ Documentação completa

## 📄 Licença

Este sistema foi desenvolvido como parte do projeto Young Money.

## 👨‍💻 Suporte

Para dúvidas ou problemas:

1. Verificar logs do servidor PHP
2. Verificar logs do Android (Logcat)
3. Consultar seção de Troubleshooting
4. Verificar queries de monitoramento

---

**Desenvolvido por Manus AI** 🤖
