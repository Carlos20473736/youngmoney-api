#!/bin/bash

# Script de teste para validar implementação XReq
# Uso: ./test_xreq.sh https://sua-api.com

API_URL="${1:-https://youngmoney-api-production.up.railway.app}"

echo "========================================="
echo "  Teste do Sistema XReq"
echo "========================================="
echo ""
echo "API URL: $API_URL"
echo ""

# Cores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para testar
test_endpoint() {
    local name=$1
    local expected=$2
    local result=$3
    
    if [ "$result" == "$expected" ]; then
        echo -e "${GREEN}✓${NC} $name"
        return 0
    else
        echo -e "${RED}✗${NC} $name"
        return 1
    fi
}

# Teste 1: Gerar XReq token
echo "Teste 1: Gerar XReq token"
echo "-------------------------"

RESPONSE=$(curl -s -X POST "$API_URL/xreq/generate.php" \
  -H "Content-Type: application/json")

echo "Resposta: $RESPONSE"
echo ""

# Verificar se retornou success
if echo "$RESPONSE" | grep -q '"success":true'; then
    echo -e "${GREEN}✓${NC} Token XReq gerado com sucesso"
    
    # Extrair token
    XREQ_TOKEN=$(echo "$RESPONSE" | grep -o '"xreq":"[^"]*"' | cut -d'"' -f4)
    echo "Token: $XREQ_TOKEN"
else
    echo -e "${RED}✗${NC} Falha ao gerar token XReq"
    exit 1
fi

echo ""
echo "========================================="
echo ""

# Teste 2: Validar formato do token
echo "Teste 2: Validar formato do token"
echo "----------------------------------"

if [[ $XREQ_TOKEN =~ ^[a-f0-9]{64}$ ]]; then
    echo -e "${GREEN}✓${NC} Token tem formato válido (64 caracteres hexadecimais)"
else
    echo -e "${RED}✗${NC} Token tem formato inválido"
    echo "Token: $XREQ_TOKEN"
    exit 1
fi

echo ""
echo "========================================="
echo ""

# Teste 3: Tentar usar endpoint protegido SEM XReq
echo "Teste 3: Endpoint protegido SEM XReq (deve falhar)"
echo "---------------------------------------------------"

RESPONSE=$(curl -s -X GET "$API_URL/ranking/list.php" \
  -H "Content-Type: application/json")

echo "Resposta: $RESPONSE"

if echo "$RESPONSE" | grep -q "XREQ_MISSING\|XReq token não fornecido"; then
    echo -e "${GREEN}✓${NC} Endpoint bloqueou requisição sem XReq"
else
    echo -e "${YELLOW}⚠${NC} Endpoint não está protegido ou erro diferente"
fi

echo ""
echo "========================================="
echo ""

# Teste 4: Usar XReq com formato inválido
echo "Teste 4: XReq com formato inválido (deve falhar)"
echo "-------------------------------------------------"

RESPONSE=$(curl -s -X GET "$API_URL/ranking/list.php" \
  -H "Content-Type: application/json" \
  -H "X-Req: invalid_token_123")

echo "Resposta: $RESPONSE"

if echo "$RESPONSE" | grep -q "XREQ_INVALID_FORMAT\|XReq token inválido"; then
    echo -e "${GREEN}✓${NC} Validação de formato funcionando"
else
    echo -e "${YELLOW}⚠${NC} Validação de formato não detectou erro"
fi

echo ""
echo "========================================="
echo ""

# Teste 5: Usar XReq válido (deve funcionar)
echo "Teste 5: Usar XReq válido (deve funcionar)"
echo "------------------------------------------"

# Gerar novo token
RESPONSE=$(curl -s -X POST "$API_URL/xreq/generate.php" \
  -H "Content-Type: application/json")
XREQ_TOKEN=$(echo "$RESPONSE" | grep -o '"xreq":"[^"]*"' | cut -d'"' -f4)

echo "Novo token gerado: $XREQ_TOKEN"

# Usar em endpoint público (ranking/list não requer auth)
RESPONSE=$(curl -s -X GET "$API_URL/ranking/list.php" \
  -H "Content-Type: application/json" \
  -H "X-Req: $XREQ_TOKEN")

echo "Resposta: $RESPONSE"

if echo "$RESPONSE" | grep -q '"success":true\|"data"'; then
    echo -e "${GREEN}✓${NC} Requisição com XReq válido funcionou"
else
    echo -e "${RED}✗${NC} Requisição com XReq válido falhou"
    echo "Possível causa: endpoint requer autenticação Bearer"
fi

echo ""
echo "========================================="
echo ""

# Teste 6: Tentar reutilizar XReq (deve falhar)
echo "Teste 6: Reutilizar XReq (deve falhar)"
echo "---------------------------------------"

RESPONSE=$(curl -s -X GET "$API_URL/ranking/list.php" \
  -H "Content-Type: application/json" \
  -H "X-Req: $XREQ_TOKEN")

echo "Resposta: $RESPONSE"

if echo "$RESPONSE" | grep -q "XREQ_ALREADY_USED\|já foi usado"; then
    echo -e "${GREEN}✓${NC} Sistema bloqueou reutilização de token"
else
    echo -e "${YELLOW}⚠${NC} Token pode ter sido reutilizado ou erro diferente"
fi

echo ""
echo "========================================="
echo ""

# Resumo
echo "Resumo dos Testes"
echo "-----------------"
echo ""
echo "✓ = Passou"
echo "✗ = Falhou"
echo "⚠ = Aviso/Inconclusivo"
echo ""
echo "Para testes completos com autenticação, use um Bearer token válido."
echo ""
echo "Exemplo:"
echo "  curl -X POST $API_URL/ranking/add_points.php \\"
echo "    -H 'Authorization: Bearer SEU_TOKEN' \\"
echo "    -H 'X-Req: \$(curl -s -X POST $API_URL/xreq/generate.php | grep -o '\"xreq\":\"[^\"]*\"' | cut -d'\"' -f4)' \\"
echo "    -H 'Content-Type: application/json' \\"
echo "    -d '{\"points\": 100, \"description\": \"Teste\"}'"
echo ""
