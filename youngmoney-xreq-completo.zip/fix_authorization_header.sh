#!/bin/bash

# Script para corrigir o problema do Authorization header

BACKEND_DIR="/home/ubuntu/youngmoney-xreq/backend"

# Lista de arquivos
FILES=(
    "api/v1/points.php"
    "api/v1/users.php"
    "api/v1/withdrawals.php"
    "history/points.php"
    "history/withdrawals.php"
    "invite/my_code.php"
    "invite/validate.php"
    "notifications/list.php"
    "notifications/mark_read.php"
    "ranking/list.php"
    "ranking/user_position.php"
    "settings/get.php"
    "settings/update.php"
    "user/balance.php"
    "user/profile.php"
    "withdraw/history.php"
    "withdraw/request.php"
)

echo "Corrigindo headers Authorization..."

for file in "${FILES[@]}"; do
    filepath="$BACKEND_DIR/$file"
    
    if [ -f "$filepath" ]; then
        echo "Corrigindo: $file"
        
        # Corrigir Authorization, X-Req para Authorization
        sed -i "s/\['Authorization, X-Req'\]/['Authorization']/g" "$filepath"
        
        echo "  ✓ Corrigido"
    fi
done

echo ""
echo "Concluído!"
