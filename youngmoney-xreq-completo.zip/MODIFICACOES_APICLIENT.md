# Modificações no ApiClient para Suporte XReq

## Resumo
Adicionar suporte automático ao header `X-Req` em todas as requisições protegidas.

## Modificações Necessárias

### 1. Adicionar campo XReqManager

Adicionar após a linha 35 (após `private String authToken;`):

```java
private XReqManager xreqManager;
```

### 2. Inicializar XReqManager no construtor

Adicionar após a linha 58 (após `loadAuthToken();`):

```java
// Inicializar XReqManager
this.xreqManager = XReqManager.getInstance(context);
```

### 3. Criar novo método executeRequestWithXReq

Adicionar após o método `executeRequest` (após linha 568):

```java
/**
 * Executa requisição HTTP com XReq token
 */
private void executeRequestWithXReq(final Request.Builder requestBuilder, final ApiCallback callback) {
    // Gerar XReq token
    xreqManager.generateXReq(authToken, new XReqManager.XReqCallback() {
        @Override
        public void onSuccess(String xreqToken) {
            // Adicionar XReq ao header
            Request request = requestBuilder
                    .addHeader("X-Req", xreqToken)
                    .build();
            
            // Executar requisição
            executeRequest(request, callback);
        }
        
        @Override
        public void onError(String error) {
            Log.e(TAG, "Failed to generate XReq: " + error);
            callback.onError("Erro ao gerar token de segurança: " + error);
        }
    });
}
```

### 4. Modificar métodos existentes

Substituir chamadas de `executeRequest` por `executeRequestWithXReq` nos seguintes métodos:

- `addPoints()` - linha 324
- `getUserPosition()` - linha 342
- `requestWithdraw()` - linha 357
- `getWithdrawHistory()` - linha 375
- `getPointsHistory()` - linha 393
- `validateInviteCode()` - linha 427
- `getMyInviteCode()` - linha 445
- `getNotifications()` - linha 462
- `markNotificationAsRead()` - linha 484
- `getSettings()` - linha 502
- `updateSettings()` - linha 520
- `getUserProfile()` - linha 248
- `updateUserProfile()` - linha 267
- `getUserBalance()` - linha 285

### 5. Modificar construção de Request

Mudar de:
```java
Request request = new Request.Builder()
    .url(...)
    .addHeader("Authorization", "Bearer " + authToken)
    .get()
    .build();

executeRequest(request, callback);
```

Para:
```java
Request.Builder requestBuilder = new Request.Builder()
    .url(...)
    .addHeader("Authorization", "Bearer " + authToken)
    .get();

executeRequestWithXReq(requestBuilder, callback);
```

## Endpoints que NÃO precisam de XReq

- `login()` - Login com Google
- `login(deviceId)` - Login com Device ID
- `logout()` - Logout
- `getRanking()` - Ranking público

Estes métodos continuam usando `executeRequest` normalmente.
